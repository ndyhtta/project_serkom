<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check if POST data is not empty
if (!empty($_POST)) {
    // Post data not empty insert a new record
    // Set-up the variables that are going to be inserted, we must check if the POST variables exist if not we can default them to blank
    $id = isset($_POST['id']) && !empty($_POST['id']) && $_POST['id'] != 'auto' ? $_POST['id'] : NULL;
    // Check if POST variable "name" exists, if not default the value to blank, basically the same for all variables
    $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
    $nim = isset($_POST['nim']) ? $_POST['nim'] : '';
    $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
    $tanggal_lahir = isset($_POST['tanggl_lahir']) ? $_POST['tanggal_lahir'] : ''; 
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $usia = isset($_POST['usia']) ? $_POST['usia'] : '';

    // Insert new record into the contacts table
    $stmt = $pdo->prepare('INSERT INTO kontak VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$id, $nama, $nim, $alamat, $tanggal_lahir, $gender, $usia,]);
    // Output message
    $msg = 'Created Successfully!';
}
?>


<?=template_header('Create')?>

<div class="content update">
	<h2>Create Data</h2>
    <form action="create.php" method="post">
        <label for="id">ID</label>
        <label for="nama">Nama</label>
        <input type="text" name="id" value="auto" id="id">
        <input type="text" name="nama" id="nama">
        <label for="nim">nim</label>
        <label for="alamat">alamat</label>
        <input type="text" name="nim" id="nim">
        <input type="text" name="alamat" id="alamat">
        <label for="tanggal_lahir">tanggal lahir</label>
        <label for="gender">Gender</label>
        <input type="date" name="tanggal_lahir" id="tanggal_lahir">
        <input type="text" name="gender" id="gender">
        <label for="usia">Usia</label>
        <label for=""></label>
        <input type="text" name="usia" id="usia">
        <input type="submit" value="Create">
    </form>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
</div>

<?=template_footer()?>