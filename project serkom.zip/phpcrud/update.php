<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check if the contact id exists, for example update.php?id=1 will get the contact with the id of 1
if (isset($_GET['id'])) {
    if (!empty($_POST)) {
        // This part is similar to the create.php, but instead we update a record and not insert
        $id = isset($_POST['id']) ? $_POST['id'] : NULL;
        $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
        $nim = isset($_POST['nim']) ? $_POST['nim'] : '';
        $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
        $tanggal_lahir = isset($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : '';
        $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
        $usia = isset($_POST['usia']) ? $_POST['usia'] : '';
        
        // Update the record
        $stmt = $pdo->prepare('UPDATE kontak SET id = ?, nama = ?, nim = ?, alamat = ?, tanggal_lahir = ?, gender = ?, usia = ? WHERE id = ?');
        $stmt->execute([$id, $nama, $nim, $alamat, $tanggal_lahir, $gender, $usia, $_GET['id']]);
        $msg = 'Updated Successfully!';
    }
    // Get the contact from the contacts table
    $stmt = $pdo->prepare('SELECT * FROM kontak WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    $contact = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$contact) {
        exit('Contact doesn\'t exist with that ID!');
    }
} else {
    exit('No ID specified!');
}
?>



<?=template_header('Read')?>

<div class="content update">
	<h2>Update Data Mahasiswa<?=$contact['id']?></h2>
    <form action="update.php?id=<?=$contact['id']?>" method="post">
        <label for="id">ID</label>
        <label for="nama">Nama</label>
        <input type="text" name="id" value="<?=$contact['id']?>" id="id">
        <input type="text" name="nama" value="<?=$contact['nama']?>" id="nama">
        <label for="nim">Nim</label>
        <label for="alamat">Alamat</label>
        <input type="text" name="nim" value="<?=$contact['nim']?>" id="nim">
        <input type="text" name="alamat" value="<?=$contact['alamat']?>" id="alamat">
        <label for="tanggal_lahir">Tanggal Lahir</label>
        <label for="gender">Gender</label>
        <input type="date" name="tanggal_lahir" value="<?=$contact['tanggal_lahir']?>" id="tanggal_lahir">
        <input type="text" name="gender" value="<?=$contact['gender']?>" id="gender">
        <label for="usia">Usia</label>
        <label for=""></label>
        <input type="text" name="usia" value="<?=$contact['usia']?>" id="usia">
        <input type="submit" value="Update">
    </form>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
</div>

<?=template_footer()?>